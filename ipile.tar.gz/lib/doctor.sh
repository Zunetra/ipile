#!/usr/bin/env bash
set -euo pipefail
echo "Running diagnostics..."
echo ""
pass() { echo "  [ok] $1"; }
fail() { echo "  [!!] $1 - not found"; }
command -v git     >/dev/null && pass "git $(git --version | awk '{print $3}')"     || fail "git"
command -v node    >/dev/null && pass "node $(node -v)"   || fail "node"
command -v pnpm    >/dev/null && pass "pnpm $(pnpm -v)"   || fail "pnpm"
command -v rustc   >/dev/null && pass "rust $(rustc -V | awk '{print $2}')" || fail "rust"
command -v ssh     >/dev/null && pass "ssh" || fail "ssh"
echo ""
echo "Run 'ipile dev-setup' to install anything missing."
