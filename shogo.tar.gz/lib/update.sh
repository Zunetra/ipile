#!/usr/bin/env bash
set -euo pipefail
INSTALL_DIR="$HOME/.shogo"
CURRENT="$(cat "$INSTALL_DIR/VERSION" 2>/dev/null || echo "unknown")"
LATEST="$(curl -fsSL https://shogo-portfolio-ebon.vercel.app/scripts/version.txt 2>/dev/null || echo "unknown")"
echo "Current: $CURRENT"
echo "Latest:  $LATEST"
if [[ "$CURRENT" == "$LATEST" ]]; then
  echo "Already up to date."
  exit 0
fi
echo "Updating Shogo CLI..."
curl -fsSL https://shogo-portfolio-ebon.vercel.app/scripts/shogo.tar.gz -o /tmp/shogo.tar.gz
tar -xzf /tmp/shogo.tar.gz -C "$INSTALL_DIR" --overwrite
echo "$LATEST" > "$INSTALL_DIR/VERSION"
echo "Updated to $LATEST. Restart your terminal."
